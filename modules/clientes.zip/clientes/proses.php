<?php

session_start();
require_once "../../config/database.php";

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
}

if ($_GET['act'] === 'insert' && isset($_POST['Guardar'])) {
    $codigo = $_POST['codigo'];
    $cod_ciudad = $_POST['codigo_ciudad'];
    $ci_ruc = $_POST['ci_ruc'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $direccion = $_POST['direccion'] ?: 'Sin registro';
    $telefono = $_POST['telefono'] ?: 0;

    $query = mysqli_query($mysql, "INSERT INTO clientes (id_cliente, cod_ciudad, ci_ruc, cli_nombre, cli_apellido, cli_direccion, cli_telefono)
    VALUES ($codigo, '$cod_ciudad', '$ci_ruc', '$nombre', '$apellido', '$direccion', $telefono)")
        or die("Error: " . mysqli_error($mysql));
    $alert = $query ? 1 : 4;
    header("Location: ../../main.php?module=clientes&alert=$alert");
}

if ($_GET['act'] === 'update' && isset($_POST['Guardar'])) {
    $codigo = $_POST['codigo'];
    $cod_ciudad = $_POST['codigo_ciudad'];
    $ci_ruc = $_POST['ci_ruc'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $direccion = $_POST['direccion'] ?: 'Sin registro';
    $telefono = $_POST['telefono'] ?: 0;

    $query = mysqli_query($mysql, "UPDATE clientes SET cod_ciudad = '$cod_ciudad',
        ci_ruc = '$ci_ruc',
        cli_nombre = '$nombre',
        cli_apellido = '$apellido',
        cli_direccion = '$direccion',
        cli_telefono = '$telefono'
        WHERE id_cliente = $codigo")
        or die("Error: " . mysqli_error($mysql));
    $alert = $query ? 2 : 4;
    header("Location: ../../main.php?module=clientes&alert=$alert");
}

if ($_GET['act'] === 'delete' && isset($_GET['id_cliente'])) {
    $codigo = $_GET['id_cliente'];
    $query = mysqli_query($mysql, "DELETE FROM clientes WHERE id_cliente = $codigo")
        or die("Error: " . mysqli_error($mysql));
    $alert = $query ? 3 : 4;
    header("Location: ../../main.php?module=clientes&alert=$alert");
}

?>